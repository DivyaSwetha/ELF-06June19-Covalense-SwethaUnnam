package com.covalense.emp.controller;

import static com.covalense.emp.common.EmpConstants.DB_INTERACTION_TYPE;
import static com.covalense.emp.common.EmpConstants.PROPERTIES_FILE;
import static com.covalense.emp.common.EmpConstants.VIEW_LOGIN_PAGE;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.covalense.emp.dao.EmployeeDAO;
import com.covalense.emp.dto.EmployeeAddressInfoBean;
import com.covalense.emp.dto.EmployeeEducationalInfo;
import com.covalense.emp.dto.EmployeeExperienceInfoBean;
import com.covalense.emp.dto.EmployeeOtherInfoBean;
import com.covalense.emp.dto.primary.EmployeeInfoBean;

@Controller
@RequestMapping("/login")
@PropertySource(PROPERTIES_FILE)
public class LoginController {
	
	@Autowired
	@Qualifier(DB_INTERACTION_TYPE)
	EmployeeDAO dao;
	

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		CustomDateEditor editor = new CustomDateEditor(new SimpleDateFormat("yyyy-MM-dd"), true);
		binder.registerCustomEditor(Date.class, editor);
	}
	
	@GetMapping("/loginpage")
	public String getIndex() {
 		return VIEW_LOGIN_PAGE;
	}
	
	@PostMapping("/authenticate")
	public String authenticate(int id,String password,ModelMap modelMap, HttpServletRequest req,@Value("${loginfail}") String msg,@Value("${dbInteractionType}") String dbInteractionType) {
		modelMap.addAttribute("eid", id);
		//EmployeeDAO dao=EmployeeDAOFactory.getInstance(dbInteractionType);
		EmployeeInfoBean emp=dao.getEmployeeInfo(id);
		if ((emp!= null) && (emp.getPassword().equals(password))) {
			HttpSession httpSession = req.getSession(true);
			httpSession.setAttribute("empInfo", emp);
			return "homePage";
		} else {
			modelMap.addAttribute("msg", msg);
			return VIEW_LOGIN_PAGE;
		}

	}
	@GetMapping("/logout")
	public String logout(HttpSession session, ModelMap modelMap,@Value("${logout}") String msg) {
		
		session.invalidate();
		modelMap.addAttribute("msg", msg);
		return VIEW_LOGIN_PAGE;
	}
	
	/*
	 * @GetMapping("/register") public String getRegisterPage() {
	 * 
	 * return "register"; }
	 * 
	 * @PostMapping("/insert") public String getRegister(EmployeeInfoBean
	 * empInfo, @RequestParam(name="mngrId") int mngrId,ModelMap
	 * modelMap, @Value("${registersuccess}") String
	 * regsuc, @Value("${registerfail}") String regfail) {
	 * 
	 * List<EmployeeEducationalInfo> eduBeans=empInfo.getEducationInfoBeans();
	 * for(EmployeeEducationalInfo empEduInfoBeans:eduBeans) {
	 * empEduInfoBeans.getEmpEducationInfo().setEmpInfo(empInfo); }
	 * List<EmployeeAddressInfoBean> addressBeans=empInfo.getAddressInfoBeans();
	 * for(EmployeeAddressInfoBean addBeans:addressBeans) {
	 * addBeans.getAddressPKBean().setEmpInfo(empInfo); }
	 * 
	 * EmployeeOtherInfoBean otherInfo=empInfo.getEmployeeOtherInfo();
	 * otherInfo.setEmpInfo(empInfo);
	 * 
	 * boolean status = dao.createEmployeeInfo(empInfo,mngrId);
	 * modelMap.addAttribute("empInfo", empInfo); if (status == true) {
	 * modelMap.addAttribute("msg",regsuc); return VIEW_LOGIN_PAGE; } else {
	 * modelMap.addAttribute("msg",regfail); return VIEW_LOGIN_PAGE; }
	 * 
	 * }
	 */
}