package com.covalense.emp.controller;

import static com.covalense.emp.common.EmpConstants.DB_INTERACTION_TYPE;
import static com.covalense.emp.common.EmpConstants.VIEW_LOGIN_PAGE;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.covalense.emp.dao.EmployeeDAO;
import com.covalense.emp.dto.EmployeeAddressInfoBean;
import com.covalense.emp.dto.EmployeeEducationalInfo;
import com.covalense.emp.dto.EmployeeOtherInfoBean;
import com.covalense.emp.dto.primary.EmployeeInfoBean;

@Controller
@RequestMapping("/employee")
public class EmployeeController {
	@Autowired
	@Qualifier(DB_INTERACTION_TYPE)
	EmployeeDAO dao;
	
	@GetMapping("/search")
	public String employeeSearch(HttpSession session,ModelMap modelMap,@RequestParam(name="id") String id) {
	         
        List<EmployeeInfoBean> idList = dao.getAllEmployeeIds(id);
		modelMap.addAttribute("id", id);
		modelMap.addAttribute("idList", idList);
		return "employeeSearch";
	}//End of search
	
	@GetMapping("/updateEmployee")
	public String getUpdateEmployee() {
		return "updateEmployee";
	}//End of getUpdateEmployee()

	@PostMapping("/updateEmployee")
	public String updateEmployee(EmployeeInfoBean empInfo,int mngrId) {
		EmployeeInfoBean mngBean=dao.getEmployeeInfo(mngrId);
		empInfo.setMngrId(mngBean);
		dao.updateEmployeeInfo(empInfo);
		return "homePage";
	}
	
	@GetMapping("/register")
	public String getRegisterPage() {

		return "register";
	}
	
	@PostMapping("/insert")
	public String getRegister(EmployeeInfoBean empInfo, @RequestParam(name="mngrId") int mngrId,ModelMap modelMap, @Value("${registersuccess}") String regsuc, @Value("${registerfail}") String regfail) {
		
		List<EmployeeEducationalInfo> eduBeans=empInfo.getEducationInfoBeans();
		for(EmployeeEducationalInfo empEduInfoBeans:eduBeans) {
			empEduInfoBeans.getEmpEducationInfo().setEmpInfo(empInfo);
		}
		List<EmployeeAddressInfoBean> addressBeans=empInfo.getAddressInfoBeans();
		for(EmployeeAddressInfoBean addBeans:addressBeans) {
			addBeans.getAddressPKBean().setEmpInfo(empInfo);
		}
		
		EmployeeOtherInfoBean otherInfo=empInfo.getEmployeeOtherInfo();
		otherInfo.setEmpInfo(empInfo);
		
		boolean status = dao.createEmployeeInfo(empInfo,mngrId);
		modelMap.addAttribute("empInfo", empInfo);
		if (status == true) {	
			modelMap.addAttribute("msg",regsuc);
			return VIEW_LOGIN_PAGE;
		} else {
			modelMap.addAttribute("msg",regfail);
			return VIEW_LOGIN_PAGE;
		}

}

	}
	
