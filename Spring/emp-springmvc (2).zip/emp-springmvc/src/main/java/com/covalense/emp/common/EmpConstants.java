package com.covalense.emp.common;

public interface EmpConstants {
String VIEW_LOGIN_PAGE="loginPage";
String PROPERTIES_FILE="classpath:emp.properties";
String DB_INTERACTION_TYPE="hibernate";
}
