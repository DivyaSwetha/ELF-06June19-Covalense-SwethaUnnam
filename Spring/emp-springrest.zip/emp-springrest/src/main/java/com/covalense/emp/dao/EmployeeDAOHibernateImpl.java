package com.covalense.emp.dao;

import java.util.Arrays;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;

import com.covalense.emp.dto.EmployeeAddressInfoBean;
import com.covalense.emp.dto.EmployeeEducationalInfo;
import com.covalense.emp.dto.EmployeeInfoBean;
import com.covalense.emp.dto.EmployeeOtherInfoBean;

import lombok.extern.java.Log;

@Log
public class EmployeeDAOHibernateImpl implements EmployeeDAO {

	@Autowired
	private SessionFactory sessionFactory;

	/*
	 * @Autowired private HibernateUtil hibernateUtil;
	 */
	@Override
	public List<EmployeeInfoBean> getAllEmployeeInfo() {
		try (Session session = sessionFactory.openSession();) {
			String hql = "from EmployeeInfoBean";
			Query query = session.createQuery(hql);
			List<EmployeeInfoBean> empBeans = query.list();
			return empBeans;
		}
	}

	@Override
	public EmployeeInfoBean getEmployeeInfo(String id) {
		return getEmployeeInfo(Integer.parseInt(id));
	}

	@Override
	public EmployeeInfoBean getEmployeeInfo(int id) {
		EmployeeInfoBean bean = null;
		try (Session session = sessionFactory.openSession();) {
			bean = session.get(EmployeeInfoBean.class, id);
			return bean;
		}
	}

	@Override
	public boolean saveOrUpdate(EmployeeInfoBean empInfo) {
		List<EmployeeEducationalInfo> eduBeans=empInfo.getEducationInfoBeans();
		for(EmployeeEducationalInfo empEduInfoBeans:eduBeans) {
			empEduInfoBeans.getEmpEducationInfo().setEmpInfo(empInfo);
		}
		List<EmployeeAddressInfoBean> addressBeans=empInfo.getAddressInfoBeans();
		for(EmployeeAddressInfoBean addBeans:addressBeans) {
			addBeans.getAddressPKBean().setEmpInfo(empInfo);
		}
		
		EmployeeOtherInfoBean otherInfo=empInfo.getEmployeeOtherInfo();
		otherInfo.setEmpInfo(empInfo);
		Transaction txn = null;
		try (Session session = sessionFactory.openSession();) {
			txn = session.beginTransaction();
			session.saveOrUpdate(empInfo);
			txn.commit();
			return true;
		} catch (Exception e) {
			log.severe(Arrays.toString(e.getStackTrace()));
			if (txn != null) {
				txn.rollback();
			}
			return false;
		}
	}

	@Override
	public boolean createEmployeeInfo(EmployeeInfoBean bean) {
		/*
		 * EmployeeInfoBean empBean=getEmployeeInfo(mngrId); empBean.setMngrId(empBean);
		 */
		return saveOrUpdate(bean);
	}

	@Override
	public boolean updateEmployeeInfo(EmployeeInfoBean bean) {
		return saveOrUpdate(bean);
	}

	@Override
	public boolean deleteEmployeeInfo(int id) {
		Transaction txn = null;
		EmployeeInfoBean bean = new EmployeeInfoBean();
		bean.setId(id);
		try (Session session = sessionFactory.openSession();) {
			txn = session.beginTransaction();
			session.delete(bean);
			txn.commit();
			return true;
		} catch (Exception e) {
			log.severe(Arrays.deepToString(e.getStackTrace()));
			if (txn != null) {
				txn.rollback();
			}
			return false;
		}
	}

	@Override
	public boolean deleteEmployeeInfo(String id) {
		return deleteEmployeeInfo(Integer.parseInt(id));
	}

	@Override
	public boolean createEmployeeOtherInfo(EmployeeOtherInfoBean bean) {
		return saveOrUpdate(bean);
	}

	@Override
	public boolean saveOrUpdate(EmployeeOtherInfoBean bean) {
		Transaction txn = null;
		try (Session session = sessionFactory.openSession();) {
			txn = session.beginTransaction();
			session.saveOrUpdate(bean);
			txn.commit();
			return true;
		} catch (Exception e) {
			log.severe(Arrays.toString(e.getStackTrace()));
			if (txn != null) {
				txn.rollback();
			}
			return false;
		}
	}

	@Override
	public List<EmployeeInfoBean> getAllEmployeeIds(String id) {
		try (Session session = sessionFactory.openSession();) {
			String hql = "from EmployeeInfoBean e where str(e.id) LIKE " + "\'" + id + "%\'";
			Query query = session.createQuery(hql);
			List<EmployeeInfoBean> empIds = query.list();

			return empIds;
		}
	}

	@Override
	public List<String> getAllEmployeeNames(String id) {
		try (Session session = sessionFactory.openSession();) {
			String hql = "select e.name from EmployeeInfoBean e where str(e.id) LIKE " + "\'" + id + "%\'";
			Query query = session.createQuery(hql);
			List<String> empNames = query.list();
			return empNames;
		}
	}
}
