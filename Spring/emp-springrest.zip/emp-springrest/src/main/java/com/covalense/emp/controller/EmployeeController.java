package com.covalense.emp.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.covalense.emp.dao.EmployeeDAO;
import com.covalense.emp.dto.EmployeeInfoBean;
//@Controller
@RestController
@RequestMapping("/employeerest")
public class EmployeeController {
	
	@Autowired
	@Qualifier("hibernate")
	EmployeeDAO dao;
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		CustomDateEditor editor = new CustomDateEditor(new SimpleDateFormat("yyyy-MM-dd"), true);
		binder.registerCustomEditor(Date.class, editor);
	}
	
	@DeleteMapping(path="/deleteEmployee")
	public boolean deleteEmployee(@RequestParam("id") int id) {
	//public @ResponseBody boolean deleteEmployee(@RequestParam("id") int id) {     //if we are using @RestController we no need to use @ResponseBody
		return dao.deleteEmployeeInfo(id);
		
	}
	
	@PostMapping(path="/createEmployee")
	public boolean createEmployee(@RequestBody EmployeeInfoBean bean) {
		return dao.createEmployeeInfo(bean);
		
	}
	
	@PutMapping(path="/updateEmployee")
	public boolean updateEmployee(@RequestBody EmployeeInfoBean bean) {
		return dao.updateEmployeeInfo(bean);
		
	}

	@GetMapping(value="/getEmployee",produces=MediaType.APPLICATION_JSON_VALUE)
	public EmployeeInfoBean getEmployee(@RequestParam("id") int id) {
		return dao.getEmployeeInfo(id);
		
	}
	
	@GetMapping(value="/getAllEmployee",produces=MediaType.APPLICATION_JSON_VALUE)
	public List<EmployeeInfoBean> getAllEmployees(){
		return dao.getAllEmployeeInfo();
		
	}
}
