package com.covalense.springboot.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlTransient;

import com.fasterxml.jackson.annotation.JsonIgnore;

@SuppressWarnings("serial")
//@XmlAccessorType(XmlAccessType.FIELD)
@Entity
@Table(name="EMPLOYEE_OTHERINFO")
public class EmployeeOtherInfoBean implements Serializable{
	@JsonIgnore
	@Id
	@GeneratedValue
	@Column(name="other_info_id")
	private int otherInfoId;
	//@JsonBackReference
	//@XmlTransient  //<===@JsonIgnore (similar)
	@JsonIgnore
	@OneToOne
	@JoinColumn(name="ID",referencedColumnName = "ID", unique = true, nullable=false)
	//@PrimaryKeyJoinColumn(name="ID")
	private EmployeeInfoBean empInfo;
	
	@Column(name="PAN")
	private String pan;
	
	@Column(name="ISMARRIED")
	private boolean ismarried;
	
	@Column(name="BLOOD_GRP")
	private String bloodGroup;
	
	@Column(name="ISCHALLENGED")
	private boolean ischallenged;
	
	@Column(name="EMERGENCY_CONTACT_NUMBER")
	private long emergencyContactNum;
	
	@Column(name="EMERGENCY_CONTACT_NAME")
	private String emergencyContactName;
	
	@Column(name="NATIONALITY")
	private String nationality;
	
	@Column(name="RELIGION")
	private String religion;
	
	@Column(name="FATHER_NM")
	private String fatherName;
	
	@Column(name="MOTHER_NM")
	private String motherName;
	
	@Column(name="SPOUSE_NM")
	private String spouseName;
	
	@Column(name="PASSPORT")
	private String passport;
	
	@Column(name="ADHAR")
	private long adhar;

	public EmployeeInfoBean getEmpInfo() {
		return empInfo;
	}

	public void setEmpInfo(EmployeeInfoBean empInfo) {
		this.empInfo = empInfo;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public boolean isIsmarried() {
		return ismarried;
	}

	public void setIsmarried(boolean ismarried) {
		this.ismarried = ismarried;
	}

	public String getBloodGroup() {
		return bloodGroup;
	}

	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}

	public boolean isIschallenged() {
		return ischallenged;
	}

	public void setIschallenged(boolean ischallenged) {
		this.ischallenged = ischallenged;
	}

	public long getEmergencyContactNum() {
		return emergencyContactNum;
	}

	public void setEmergencyContactNum(long emergencyContactNum) {
		this.emergencyContactNum = emergencyContactNum;
	}

	public String getEmergencyContactName() {
		return emergencyContactName;
	}

	public void setEmergencyContactName(String emergencyContactName) {
		this.emergencyContactName = emergencyContactName;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getReligion() {
		return religion;
	}

	public void setReligion(String religion) {
		this.religion = religion;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public String getMotherName() {
		return motherName;
	}

	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}

	public String getSpouseName() {
		return spouseName;
	}

	public void setSpouseName(String spouseName) {
		this.spouseName = spouseName;
	}

	public String getPassport() {
		return passport;
	}

	public void setPassport(String passport) {
		this.passport = passport;
	}

	public long getAdhar() {
		return adhar;
	}

	public void setAdhar(long adhar) {
		this.adhar = adhar;
	}

	public int getOtherInfoId() {
		return otherInfoId;
	}

	public void setOtherInfoId(int otherInfoId) {
		this.otherInfoId = otherInfoId;
	}

}
