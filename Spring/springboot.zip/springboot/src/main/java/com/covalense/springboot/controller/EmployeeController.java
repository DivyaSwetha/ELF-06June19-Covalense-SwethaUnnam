package com.covalense.springboot.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.covalense.springboot.dto.EmployeeAddressInfoBean;
import com.covalense.springboot.dto.EmployeeEducationalInfo;
import com.covalense.springboot.dto.EmployeeExperienceInfoBean;
import com.covalense.springboot.dto.EmployeeInfoBean;
import com.covalense.springboot.dto.EmployeeResponse;
import com.covalense.springboot.repositry.EmployeeRepositry;

@RestController
public class EmployeeController {

	@Autowired
	EmployeeRepositry repositry;
	
	@GetMapping(path="/hello",produces = MediaType.TEXT_PLAIN_VALUE)
	public String helloWorld() {
		return "Hello World!!!";
	}
	
	@PostMapping(path="/create",
				 produces=MediaType.APPLICATION_JSON_VALUE,
				 consumes=MediaType.APPLICATION_JSON_VALUE)
	public EmployeeResponse createEmployee(@RequestBody EmployeeInfoBean bean) {
		
		bean=empDetails(bean);
		EmployeeResponse response=new EmployeeResponse();
		if(!repositry.existsById(bean.getId())){
			repositry.save(bean);
			response.setStatusCode(201);
			response.setMessage("Successful");
			response.setDescription("Employee data added successfully");
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed!");
			response.setDescription("Employee data is already present!!!");
		}
		return response;
		
	}
	
	@GetMapping(path="/get",
				produces = MediaType.APPLICATION_JSON_VALUE)
	public EmployeeResponse getEmployee(@RequestParam("id") int id) {
		EmployeeResponse response=new EmployeeResponse();
		if(repositry.existsById(id)) {
			EmployeeInfoBean bean=repositry.findById(id).get();
			response.setStatusCode(201);
			response.setMessage("Successful");
			response.setDescription("Employee data found successfully");
			response.setBeans(Arrays.asList(bean));
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed!");
			response.setDescription("Employee data not found!!!");
		}
		return response;
	}
	
	@GetMapping(path="/getAll",
				produces = MediaType.APPLICATION_JSON_VALUE)
	public EmployeeResponse getAllEmployee() {
		List<EmployeeInfoBean> beans=(List<EmployeeInfoBean>) repositry.findAll().iterator();
		EmployeeResponse response=new EmployeeResponse();
		if(beans!=null) {
			response.setStatusCode(201);
			response.setMessage("Successful");
			response.setDescription("All Employees details found successfully");
			response.setBeans(beans);
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed!");
			response.setDescription("Employees details not found!!!");
		}
		return response;
	}
	
	@DeleteMapping(path="/delete",
				   produces = MediaType.APPLICATION_JSON_VALUE)
	public EmployeeResponse deleteEmployee(@RequestParam("id") int id) {
		EmployeeResponse response=new EmployeeResponse();
		if(repositry.existsById(id)) {
			repositry.deleteById(id);
			response.setStatusCode(201);
			response.setMessage("Successful");
			response.setDescription("Employee data deleted successfully");
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed!");
			response.setDescription("Employees details not found!!!");
		}
		
		return response;
		
	}
	
	@PutMapping(path="/update",
				produces = MediaType.APPLICATION_JSON_VALUE,
				consumes = MediaType.APPLICATION_JSON_VALUE)
	public EmployeeResponse updateEmployee(@RequestBody EmployeeInfoBean bean) {
		

		EmployeeResponse response=new EmployeeResponse();
		if(repositry.existsById(bean.getId())) {
			bean=empDetails(bean);
			repositry.save(bean);
			response.setStatusCode(201);
			response.setMessage("Successful");
			response.setDescription("Employee data updated successfully");
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed!");
			response.setDescription("Employees details not updated!!!");
		}
		return response;
	}
	
	public EmployeeInfoBean empDetails(EmployeeInfoBean bean) {
		bean.getEmployeeOtherInfo().setEmpInfo(bean);
		for(EmployeeAddressInfoBean addressBeans:bean.getAddressInfoBeans()) {
			addressBeans.getAddressPKBean().setEmpInfo(bean);
		}
		for(EmployeeEducationalInfo eduBeans:bean.getEducationInfoBeans()) {
			eduBeans.getEmpEducationInfo().setEmpInfo(bean);
		}
		/*
		 * for(EmployeeExperienceInfoBean expBeans:bean.getExperienceInfoBeans()) {
		 * expBeans.getEmpPKBean().setEmpInfo(bean); }
		 */
		EmployeeInfoBean manager=bean.getMngrId();
		manager=repositry.findById(manager.getId()).get();
		return bean;
	}
}
