package com.covalense.springboot.repositry;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.covalense.springboot.dto.EmployeeInfoBean;
import com.covalense.springboot.dto.EmployeeOtherInfoBean;

public interface EmployeeRepositry extends CrudRepository<EmployeeInfoBean, Integer>{
	@Query("Select e from EmployeeOtherInfoBean e where e.empInfo=:id")
	public EmployeeOtherInfoBean findByEmpId(@Param("id") EmployeeInfoBean bean);
	
	/*
	 * @Query("Select e.otherInfoId from EmployeeOtherInfoBean e where e.empInfo=:id"
	 * ) public int findOtherEmpById(@Param("id") int id);
	 */
	@Query("Select emp from EmployeeInfoBean emp where emp.id=:id")
	public EmployeeInfoBean findEmpById(@Param("id") int id);

}
