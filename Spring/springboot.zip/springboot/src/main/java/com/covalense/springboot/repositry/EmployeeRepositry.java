package com.covalense.springboot.repositry;

import org.springframework.data.repository.CrudRepository;

import com.covalense.springboot.dto.EmployeeInfoBean;

public interface EmployeeRepositry extends CrudRepository<EmployeeInfoBean, Integer>{

}
