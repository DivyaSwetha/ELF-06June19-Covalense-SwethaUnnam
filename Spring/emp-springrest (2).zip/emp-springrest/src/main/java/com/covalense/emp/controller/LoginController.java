package com.covalense.emp.controller;


import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.covalense.emp.dao.EmployeeDAO;
import com.covalense.emp.dto.EmployeeInfoBean;
import com.covalense.emp.dto.EmployeeResponse;

@RestController
@RequestMapping("/login")
public class LoginController {
	
	@Autowired
	@Qualifier("hibernate")
	EmployeeDAO dao;
	
	/*
	 * @Autowired EmployeeResponse response;
	 */
	
    @PostMapping(value="/authentication",
    			produces = MediaType.APPLICATION_JSON_VALUE)
	public EmployeeResponse login(int id,String password,HttpServletRequest request) {
    	EmployeeInfoBean bean=dao.getEmployeeInfo(id);
    	EmployeeResponse response=new EmployeeResponse();
    	if(bean!=null&&bean.getPassword().equals(password)) {
    		response.setStatusCode(201);
			response.setMessage("Successfull");
			response.setDescription("login successfull");
			response.setBeans(Arrays.asList(bean));
			request.getSession().setAttribute("bean", bean);
		}else {
			response.setStatusCode(401);
			response.setMessage("Failed!");
			response.setDescription("invalid credentials!!! login failed");
		}
		return response;
	}
    
	@GetMapping(value="/logout",produces = MediaType.APPLICATION_JSON_VALUE)
	public EmployeeResponse logout(HttpSession session) {
		session.invalidate();
		EmployeeResponse response=new EmployeeResponse();
		response.setStatusCode(201);
		response.setMessage("Successfull");
		response.setDescription("logged out successfully");
		return response;
	}
	
	@GetMapping(value="/readCookie",produces = MediaType.APPLICATION_JSON_VALUE)
	public EmployeeResponse readCookie(@CookieValue(name="JSESSIONID") String sessionId){
		EmployeeResponse response=new EmployeeResponse();
		response.setStatusCode(201);
		response.setMessage("Successfull");
		response.setDescription("JSESSIONID"+sessionId);
		return response;
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	

}