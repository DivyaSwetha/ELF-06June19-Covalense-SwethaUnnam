package com.covalense.emp.controller;

import lombok.Data;

@Data
public class UserBean {
private int id;
private String password;

}
