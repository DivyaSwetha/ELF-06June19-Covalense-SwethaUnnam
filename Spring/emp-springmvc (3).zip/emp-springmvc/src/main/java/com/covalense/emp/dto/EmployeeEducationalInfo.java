package com.covalense.emp.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.covalense.emp.compositebeans.EmployeeEducationalPKBean;

import lombok.Data;

@Data
@Entity
@Table(name="employee_educational_info")
public class EmployeeEducationalInfo implements Serializable {
	@EmbeddedId
	private EmployeeEducationalPKBean empEducationInfo;
	@Column(name="DEGREE_TYPE")
	private String degreeType;
	@Column(name="BRANCH")
	private String branch;
	@Column(name="COLLEGE_NM")
	private String collegeName;
	@Column(name="UNIVERSITY")
	private String university;
	@Column(name="YOP")
	private String yop;
	@Column(name="PERCENTAGE")
	private double percentage;
	@Column(name="LOCATION")
	private String location;

}
