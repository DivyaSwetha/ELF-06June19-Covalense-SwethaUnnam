package com.covalense.emp.dto;

import lombok.Data;

@Data
public class UserBean {
private int id;
private String password;
}
