import React from 'react';
import './App.css';
import AdminHome from './components/AdminHomePage/Homepage';
import User from './components/User/user';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom'
import Login from './components/Login/Login'
import UserHome from './components/UserHome/UserHome';
import BookAdd from './components/Book/BookAdd';
function App() {
  return (
    
    <Router>
    <Route  exact path='/' component={Login}></Route>
    <Route path='/adminhome' component={AdminHome} ></Route>
    <Route  path='/adduser' component={User}></Route>
  {/*   <Route path='/viewaccounts' component={ViewAccounts}></Route> */}
    </Router>

  );
}

export default App;
 