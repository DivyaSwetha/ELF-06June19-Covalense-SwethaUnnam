import React from 'react';
import './App.css';
import AdminHome from './components/AdminHomePage/Homepage';
import User from './components/User/user';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom'
import Login from './components/Login/Login'
import UserHome from './components/UserHome/UserHome';
import BookAdd from './components/Book/BookAdd';
import SearchPage from './components/AdminHomePage/SearchPage';
import LibrarianHome from './components/Librarian/LibrarianHome';
function App() {
  return (
    
    <Router>
    <Route  exact path='/' component={Login}></Route>
    <Route path='/adminhome' component={AdminHome} ></Route>
    <Route path='/searching' component={SearchPage}></Route>
    <Route  path='/adduser' component={User}></Route>
    <Route path='/userhome' component={UserHome}></Route>
    <Route path='/libhome' component={LibrarianHome}></Route>
    <Route path='/addbook' component={BookAdd}></Route>
  {/*   <Route path='/viewaccounts' component={ViewAccounts}></Route> */}
    </Router>

  );
}

export default App;
 