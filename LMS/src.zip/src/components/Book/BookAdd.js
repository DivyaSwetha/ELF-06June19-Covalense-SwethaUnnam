import React from 'react'


export class BookAdd extends React.Component{
    render(){
        return (
                    <div>
<div className="card bg-dark text-white mb-6" style={{maxWidth: '50rem',marginLeft:'30rem',marginTop:'10rem'}}>
<div className="card-header" >
        <b style={{marginLeft:'21rem',fontSize:'20'}}>Book Details</b>
      </div>
<form>
<div className="form-group row" style={{marginTop:'2rem',paddingRight:'1rem',paddingLeft:'1rem'}}>
          <label htmlFor="inputEmail3" className="col-sm-2 col-form-label">Book No:</label>
          <div className="col-sm-10">
            <input type="number" className="form-control" id="inputEmail3" placeholder="Enter Book No" />
          </div>
        </div>
      {/*   <div className="form-group row">
          <label htmlFor="inputEmail3" className="col-sm-2 col-form-label"></label>
          <div className="col-sm-10">
            <input type="email" className="form-control" id="inputEmail3" placeholder="Enter user name" />
          </div>
        </div> */}
        
        <div className="form-group row" style={{paddingRight:'1rem',paddingLeft:'1rem'}}>
          <label htmlFor="inputEmail3" className="col-sm-2 col-form-label" >Title</label>
          <div className="col-sm-10">
            <input type="text" className="form-control" id="inputEmail3" placeholder="Enter Book title" />
          </div>
        </div>
        <div className="form-group row" style={{paddingRight:'1rem',paddingLeft:'1rem'}}>
          <label htmlFor="inputPassword3" className="col-sm-2 col-form-label">Author</label>
          <div className="col-sm-10">
            <input type="text" className="form-control" id="inputPassword3" placeholder="Author" />
          </div>
        </div>
        <div className="form-group row" style={{paddingRight:'1rem',paddingLeft:'1rem'}}>
          <label htmlFor="inputPassword3" className="col-sm-2 col-form-label">Category</label>
          <div className="col-sm-10">
            <input type="text" className="form-control" id="inputPassword3" placeholder="Book Category" />
          </div>
        </div>
        <div className="form-group row" style={{paddingRight:'1rem',paddingLeft:'1rem'}}>
          <label htmlFor="inputPassword3" className="col-sm-2 col-form-label">Publisher</label>
          <div className="col-sm-10">
            <input type="text" className="form-control" id="inputPassword3" placeholder="Publisher" />
          </div>
        </div>
        <div className="form-group row" style={{paddingRight:'1rem',paddingLeft:'1rem'}}>
          <label htmlFor="inputPassword3" className="col-sm-2 col-form-label">Year of publish</label>
          <div className="col-sm-10">
            <input type="date" className="form-control" id="inputPassword3" placeholder="Year of publish" />
          </div>
        </div>
   
        <div className="form-group row " >
          <div className="col-sm-10 ">
            <button type="submit" className="btn btn-primary" style={{marginLeft:'22rem'}} >Add</button>
          </div>
        </div>
        <div className="form-group row" style={{marginTop:'2rem',paddingRight:'1rem',paddingLeft:'1rem'}}>
          <label htmlFor="inputEmail3" className="col-sm-2 col-form-label">Number of copies</label>
          <div className="col-sm-10">
            <input type="number" className="form-control" id="inputEmail3" placeholder="Total copies" />
          </div>
        </div>
        <div className="form-group row" style={{marginTop:'2rem',paddingRight:'1rem',paddingLeft:'1rem'}}>
          <label htmlFor="inputEmail3" className="col-sm-2 col-form-label">Currently Available</label>
          <div className="col-sm-10">
            <input type="number" className="form-control" id="inputEmail3" placeholder="Currently Available" />
          </div>
        </div>
      </form>

                        
                    </div>
                    </div>

        );
    }
}


export default BookAdd;