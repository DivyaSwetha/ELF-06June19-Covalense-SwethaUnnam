import React from 'react'
import Axios from 'axios';
import {Link,Router} from 'react-router-dom'
import '../Login/Login.css'

export class Login extends React.Component{
  constructor(props){
    super(props)
        this.state={
            userType:'',
            userId:'',
            password:'',
        }
        this.postData=this.postData.bind(this);
    }

    postData(event){
        event.preventDefault();
        console.log('post Data',this.state);
        let accountDate=this.state;
        Axios.post('http://localhost:8081/authentication',null,
        {params:{userType:this.state.userType,
                  userId:this.state.userId,
                 password:this.state.password}})
        .then((response)=>{
             console.log('Response object',response.data);
             if(response.data.statusCode===201){
              sessionStorage.setItem("emp",JSON.stringify(response.data.beans[0]))
              if(response.data.beans[0].userType==="admin"){
        this.props.history.push('/adminhome')
              }else if(response.data.beans[0].userType==="Librarian"){
                this.props.history.push('/libhome')
              }else{
                this.props.history.push('/userhome')
              }
       

             }else{
                 this.props.history.push('/')
             }

      
    }).catch((error)=>{console.log('Error',error);alert('Invalid credentials!!!')});
 
     
  }


render(){
    return (
            
              <div className="card text-white" style={{maxWidth: '30rem',marginTop:'10rem',marginLeft:'35rem',backgroundColor: 'black', opacity: '0.5'}}>
        <div className="card-header" style={{fontSize:25,marginLeft:'4rem'}}>Library Management System</div>
        <div className="card-body">
         
          <form onSubmit={this.postData}>
          <div className="form-group">
        <label htmlFor="sel1">Login as:</label>
        <select className="form-control" id="sel1" name="userType" onChange={(event)=>{this.setState({userType:event.target.value})}} value={this.state.userType}>
          <option>Select</option>
          <option>User</option>
          <option>Librarian</option>
          <option>Admin</option>
        </select>
      </div>
        <div className="form-group">
          <label htmlFor="exampleInputEmail1">Id</label>
          <input type="number" className="form-control" id="exampleInputEmail1" name="userId" onChange={(event)=>{this.setState({userId:event.target.value})}} value={this.state.userId} aria-describedby="emailHelp" placeholder="Enter your library ID" />
        </div>
        <div className="form-group">
          <label htmlFor="exampleInputPassword1">Password</label>
          <input type="password" className="form-control" id="exampleInputPassword1" name="password" onChange={(event)=>{this.setState({password:event.target.value})}} value={this.state.password} placeholder="Password" />
        </div>
       
        <button type="submit" className="btn btn-primary " style={{marginLeft:'10rem'}}>Submit</button>
      </form>
        </div>
      </div>


    );
}



}


export default Login;