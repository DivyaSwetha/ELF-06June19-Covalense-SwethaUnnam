import React from 'react'
import Axios from 'axios';
import {Link,Router} from 'react-router-dom'
import '../Login/Login.css'

export class Login extends React.Component{
  constructor(props){
    super(props)
        this.state={
            emailId:'',
            password:'',
        }
        this.postData=this.postData.bind(this);
    }

    postData(event){
        event.preventDefault();
        console.log('post Data',this.state);
        let accountDate=this.state;
        Axios.post('http://localhost:700/login',null,
        {params:{
          emailId:this.state.emailId,
                 password:this.state.password}})
        .then((response)=>{
             console.log('Response object',response);
             if(response.data.statusCode===201){
                     sessionStorage.setItem("emp",JSON.stringify(response.data.beans[0]))
                   this.props.history.push('/adminhome')
       

             }else{
                 this.props.history.push('/')
             }

      
    }).catch((error)=>{console.log('Error',error)})
 
     
  }


render(){
    return (
            
              <div className="card text-white bg-dark" style={{maxWidth: '30rem',marginTop:'10rem',marginLeft:'35rem'}}>
        <div className="card-header" style={{fontSize:25,marginLeft:'4rem'}}>Library Management System</div>
        <div className="card-body">
         
          <form onSubmit={this.postData}>
        
        <div className="form-group">
          <label htmlFor="exampleInputEmail1">email</label>
          <input type="mail" className="form-control" id="exampleInputEmail1" name="emailId" onChange={(event)=>{this.setState({emailId:event.target.value})}} value={this.state.emailId} aria-describedby="emailHelp" placeholder="Enter your library ID" />
        </div>
        <div className="form-group">
          <label htmlFor="exampleInputPassword1">Password</label>
          <input type="password" className="form-control" id="exampleInputPassword1" name="password" onChange={(event)=>{this.setState({password:event.target.value})}} value={this.state.password} placeholder="Password" />
        </div>
       
        <button type="submit" className="btn btn-primary " style={{marginLeft:'10rem'}}>Submit</button>
      </form>
        </div>
      </div>


    );
}



}


export default Login;