import React from 'react'
import Axios from 'axios';


export class User extends React.Component{
  constructor(props){
    super(props)
        this.state={
          userId:'',
          userType:'',
          userName:'',
          phoneNo:'',
          mailId:'',
          joiningDate:'',
          adminId:'',
          librarianId:'',
          password:''
        }
    this.postData=this.postData.bind(this);
}


postData(event){
    event.preventDefault();
  /*   this.state.validation(); */
    console.log('post Data',this.state);
    let accountDate=this.state;
    Axios.post('http://localhost:8081/createUser', 
     {params:{userId:this.state.userId,
              userType:this.state.userType,
              userName:this.state.userName,
              phoneNo:this.state.phoneNo,
              mailId:this.state.mailId,
              joiningDate:this.state.joiningDate,
              adminId:this.state.adminId,
              librarianId:this.state.librarianId,
              password:this.state.password}}
   ).then((response)=>{console.log('Response object',Response);
    /* this.setState({
      userId:'',
        email:'',
        phoneno:'',
        password:''
    }) */
    if(Response.statusCode===201){
      this.props.history.push('/adminhome')
    }
  }).catch((error)=>{console.log('Error',error)});


}  


    render(){
        return (
                    <div>
<div className="card text-whitesmoke mb-6" style={{maxWidth: '50rem',marginLeft:'30rem',marginTop:'4rem',backgroundColor: 'black', opacity: '0.6',color:"whitesmoke"}}>
<div className="card-header" >
        <b style={{marginLeft:'21rem',fontSize:'20'}}>User Details</b>
      </div>
<form onSubmit={this.postData} >
<div className="form-group row" style={{marginTop:'2rem',paddingRight:'1rem',paddingLeft:'1rem'}}>
          <label htmlFor="inputEmail3" className="col-sm-2 col-form-label">User Id:</label>
          <div className="col-sm-10">
            <input type="number" name='userId' className="form-control" id="inputEmail3" placeholder="Enter user Id" onChange={(event)=>{this.setState({userId:event.target.value})}} value={this.state.userId} />
          </div>
        </div>
      {/*   <div className="form-group row">
          <label htmlFor="inputEmail3" className="col-sm-2 col-form-label"></label>
          <div className="col-sm-10">
            <input type="email" className="form-control" id="inputEmail3" placeholder="Enter user name" />
          </div>
        </div> */}
        <fieldset className="form-group" style={{paddingRight:'1rem',paddingLeft:'1rem'}} >
          <div className="row">
            <legend className="col-form-label col-sm-2 pt-0">User Type:</legend>
            <div className="col-sm-10">
              <div className="form-check">
                <input className="form-check-input" name="userType" type="radio" name="gridRadios" id="gridRadios1" defaultValue="option1" defaultChecked onChange={(event)=>{this.setState({userType:event.target.value})}} value={this.state.userType}/>
                <label className="form-check-label" htmlFor="gridRadios1">
               User
                </label>
              </div>
              <div className="form-check">
                <input className="form-check-input" type="radio" name="gridRadios" id="gridRadios2" defaultValue="option2" onChange={(event)=>{this.setState({name:event.target.value})}} value={this.state.name} />
                <label className="form-check-label" htmlFor="gridRadios2">
                  Librarian
                </label>
              </div>
              <div className="form-check disabled">
                <input className="form-check-input" type="radio" name="gridRadios" id="gridRadios3" defaultValue="option3" disabled onChange={(event)=>{this.setState({name:event.target.value})}} value={this.state.name}/>
                <label className="form-check-label" htmlFor="gridRadios3">
                 Admin
                </label>
              </div>
            </div>
          </div>
        </fieldset>
        <div className="form-group row" style={{paddingRight:'1rem',paddingLeft:'1rem'}}>
          <label htmlFor="inputEmail3" className="col-sm-2 col-form-label" >Name</label>
          <div className="col-sm-10">
            <input type="text" className="form-control" name="userName" id="inputEmail3" placeholder="Enter user name" onChange={(event)=>{this.setState({userName:event.target.value})}} value={this.state.userName}/>
          </div>
        </div>
        <div className="form-group row" style={{paddingRight:'1rem',paddingLeft:'1rem'}}>
          <label htmlFor="inputPassword3" className="col-sm-2 col-form-label">Password</label>
          <div className="col-sm-10">
            <input type="password" className="form-control" id="inputPassword3" placeholder="Password" onChange={(event)=>{this.setState({name:event.target.value})}} value={this.state.name}/>
          </div>
        </div>
        <div className="form-group row" style={{paddingRight:'1rem',paddingLeft:'1rem'}}>
          <label htmlFor="inputPassword3" className="col-sm-2 col-form-label">Phone no.</label>
          <div className="col-sm-10">
            <input type="number" name="phoneNo" className="form-control" id="inputPassword3" placeholder="Enter user Mobile no." onChange={(event)=>{this.setState({phoneNo:event.target.value})}} value={this.state.phoneNo}/>
          </div>
        </div>
        <div className="form-group row" style={{paddingRight:'1rem',paddingLeft:'1rem'}}>
          <label htmlFor="inputPassword3" className="col-sm-2 col-form-label">Mail Id.</label>
          <div className="col-sm-10">
            <input type="mail" name="mailId" className="form-control" id="inputPassword3" placeholder="Enter user Mail id" onChange={(event)=>{this.setState({mailId:event.target.value})}} value={this.state.mailId}/>
          </div>
        </div>
        <div className="form-group row" style={{paddingRight:'1rem',paddingLeft:'1rem'}}>
          <label htmlFor="inputPassword3" className="col-sm-2 col-form-label">Joining date</label>
          <div className="col-sm-10">
            <input type="date" name="joiningDate" className="form-control" id="inputPassword3" placeholder="Enter user Joining date" onChange={(event)=>{this.setState({joiningDate:event.target.value})}} value={this.state.joiningDate}/>
          </div>
        </div>
        <div className="form-group row" style={{paddingRight:'1rem',paddingLeft:'1rem'}}>
          <label htmlFor="inputPassword3" className="col-sm-2 col-form-label">Admin Id.</label>
          <div className="col-sm-10">
            <input type="number" name="adminId" className="form-control" id="inputPassword3" placeholder="Enter user Admin id" onChange={(event)=>{this.setState({adminId:event.target.value})}} value={this.state.adminId}/>
          </div>
        </div>
        <div className="form-group row" style={{paddingRight:'1rem',paddingLeft:'1rem'}}>
          <label htmlFor="inputPassword3" className="col-sm-2 col-form-label">Librarian Id.</label>
          <div className="col-sm-10">
            <input type="number" name="librarianId" className="form-control" id="inputPassword3" placeholder="Enter user Librarian id" onChange={(event)=>{this.setState({librarianId:event.target.value})}} value={this.state.librarianId}/>
          </div>
        </div>
       {/*  <div className="form-group row" style={{paddingRight:'1rem',paddingLeft:'1rem'}}>
          <label htmlFor="inputPassword3" className="col-sm-2 col-form-label">Password</label>
          <div className="col-sm-10">
            <input type="text" name="password" className="form-control" id="inputPassword3" placeholder="Enter user password" onChange={(event)=>{this.setState({password:event.target.value})}} value={this.state.password}/>
          </div>
        </div> */}
   
        <div className="form-group row " >
          <div className="col-sm-10 ">
            <button type="submit" className="btn btn-primary" style={{marginLeft:'22rem'}} >Add</button>
          </div>
        </div>
      </form>

                        
                    </div>
                    </div>

        );
    }
}


export default User;