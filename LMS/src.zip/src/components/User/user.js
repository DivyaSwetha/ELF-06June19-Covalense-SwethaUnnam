import React from 'react'


export class User extends React.Component{
    render(){
        return (
                    <div>
<div className="card bg-dark text-white mb-6" style={{maxWidth: '50rem',marginLeft:'30rem',marginTop:'10rem'}}>
<div className="card-header" >
        <b style={{marginLeft:'21rem',fontSize:'20'}}>User Details</b>
      </div>
<form>
<div className="form-group row" style={{marginTop:'2rem',paddingRight:'1rem',paddingLeft:'1rem'}}>
          <label htmlFor="inputEmail3" className="col-sm-2 col-form-label">User Id:</label>
          <div className="col-sm-10">
            <input type="email" className="form-control" id="inputEmail3" placeholder="Enter user Id" />
          </div>
        </div>
      {/*   <div className="form-group row">
          <label htmlFor="inputEmail3" className="col-sm-2 col-form-label"></label>
          <div className="col-sm-10">
            <input type="email" className="form-control" id="inputEmail3" placeholder="Enter user name" />
          </div>
        </div> */}
        <fieldset className="form-group" style={{paddingRight:'1rem',paddingLeft:'1rem'}}>
          <div className="row">
            <legend className="col-form-label col-sm-2 pt-0">User Type:</legend>
            <div className="col-sm-10">
              <div className="form-check">
                <input className="form-check-input" type="radio" name="gridRadios" id="gridRadios1" defaultValue="option1" defaultChecked />
                <label className="form-check-label" htmlFor="gridRadios1">
               User
                </label>
              </div>
              <div className="form-check">
                <input className="form-check-input" type="radio" name="gridRadios" id="gridRadios2" defaultValue="option2" />
                <label className="form-check-label" htmlFor="gridRadios2">
                  Librarian
                </label>
              </div>
              <div className="form-check disabled">
                <input className="form-check-input" type="radio" name="gridRadios" id="gridRadios3" defaultValue="option3" disabled />
                <label className="form-check-label" htmlFor="gridRadios3">
                 Admin
                </label>
              </div>
            </div>
          </div>
        </fieldset>
        <div className="form-group row" style={{paddingRight:'1rem',paddingLeft:'1rem'}}>
          <label htmlFor="inputEmail3" className="col-sm-2 col-form-label" >Name</label>
          <div className="col-sm-10">
            <input type="email" className="form-control" id="inputEmail3" placeholder="Enter user name" />
          </div>
        </div>
        <div className="form-group row" style={{paddingRight:'1rem',paddingLeft:'1rem'}}>
          <label htmlFor="inputPassword3" className="col-sm-2 col-form-label">Password</label>
          <div className="col-sm-10">
            <input type="password" className="form-control" id="inputPassword3" placeholder="Password" />
          </div>
        </div>
        <div className="form-group row" style={{paddingRight:'1rem',paddingLeft:'1rem'}}>
          <label htmlFor="inputPassword3" className="col-sm-2 col-form-label">Phone no.</label>
          <div className="col-sm-10">
            <input type="number" className="form-control" id="inputPassword3" placeholder="Enter user Mobile no." />
          </div>
        </div>
        <div className="form-group row" style={{paddingRight:'1rem',paddingLeft:'1rem'}}>
          <label htmlFor="inputPassword3" className="col-sm-2 col-form-label">Mail Id.</label>
          <div className="col-sm-10">
            <input type="mail" className="form-control" id="inputPassword3" placeholder="Enter user Mail id" />
          </div>
        </div>
   
        <div className="form-group row " >
          <div className="col-sm-10 ">
            <button type="submit" className="btn btn-primary" style={{marginLeft:'22rem'}} >Add</button>
          </div>
        </div>
      </form>

                        
                    </div>
                    </div>

        );
    }
}


export default User;