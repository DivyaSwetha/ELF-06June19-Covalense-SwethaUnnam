import React from 'react'
import {Link} from 'react-router-dom'
import Axios from 'axios';
export class SearchPage extends React.Component{
  constructor(props){
    super(props)
    this.state={
      userId:'',
      details:JSON.parse(sessionStorage.getItem("searching"))
    }
    this.searchData=this.searchData.bind(this);

  }

  searchData(event){
    event.preventDefault();
    /*   this.state.validation(); */
      console.log('search Data',this.state);
      let accountDate=this.state;
      Axios.get('http://localhost:8081/searchUser', 
       {params:{userId:this.state.userId}}
     ).then((response)=>{console.log('Response object',Response);
      /* this.setState({
        userId:'',
          email:'',
          phoneno:'',
          password:''
      }) */
      this.props.history.push('/searching')
      sessionStorage.setItem("searching",JSON.stringify(response.data))
    }).catch((error)=>{console.log('Error',error)});
  
  }
    render(){
        return (
                    <div>

                            
      <nav className="navbar navbar-expand-lg bg-dark">
        <a className="navbar-brand" href="#"  style={{color:"whitesmoke"}}>LMS</a>
        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon" />
        </button>
        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav mr-auto">
            <li className="nav-item active">
              <a className="nav-link" href="#"  style={{color:"whitesmoke"}}>Home <span className="sr-only">(current)</span></a>
            </li>
            <li className="nav-item">
              <Link to='/' ><a className="nav-link" href="#"  style={{color:"whitesmoke"}}>Logout</a></Link>
            </li>
            <li className="nav-item dropdown">
              <a className="nav-link dropdown-toggle"  style={{color:"whitesmoke"}} href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Users
              </a>
              <div className="dropdown-menu"  style={{color:"whitesmoke"}} aria-labelledby="navbarDropdown">
                <Link to="/adduser"><a className="dropdown-item" >Add User</a></Link>
                <a className="dropdown-item" href="#">Delete User</a>
                <a className="dropdown-item" href="#">Edit User</a>
              </div>
            </li>
         
          </ul>
          <form className="form-inline my-2 my-lg-0" onSubmit={this.searchData}>
            <input className="form-control mr-sm-2" type="search" name="userId" onChange={(event)=>{this.setState({userId:event.target.value})}} value={this.state.userId} placeholder="Search User" aria-label="Search" style={{width:"50rem"}} />
            <button className="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
          </form>
        </div>
      </nav>
      <div className="form-inline" style={{marginLeft:'20rem'}}>    
       <table className="table table-dark col-md-6 col-md-offset-3" style={{marginTop:'5rem',maxWidth:'25rem'}}>
        <thead>
          <tr>
            <th scope="col" colSpan={3}>User Details</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">Name</th>
            <td>{this.state.details.userId}</td>
          </tr>
          <tr>
            <th scope="row">Name</th>
            <td>{this.state.details.userName}</td>
          </tr>
          <tr>
            <th scope="row">Phone no.</th>
            <td>this.state.details.phoneNo</td>
          </tr>
        </tbody>
      </table>
     
</div>

                    </div>



        );
    }
}


export default SearchPage;