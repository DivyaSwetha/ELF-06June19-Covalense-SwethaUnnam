package com.covalense.lms.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="fine_info")
public class FineInfoBean implements Serializable{
	
	/*
	 * @JsonIgnore
	 * 
	 * @Id
	 * 
	 * @GeneratedValue
	 * 
	 * @Column(name="fine_info_id") private int fineInfoId;
	 */
	
	/*
	 * @JsonIgnore
	 * 
	 * @OneToOne
	 * 
	 * @JoinColumn(name="user_id",referencedColumnName = "user_id", unique = true,
	 * nullable=false) private UserInfoBean userInfo;
	 */
	@Id
	@Column(name="user_id")
	private int userId;
	@Column(name="fine_amount")
	private double fineAmount;
	@Column(name="fine_description")
	private String fineDescription;
	
	public double getFineAmount() {
		return fineAmount;
	}
	public void setFineAmount(double fineAmount) {
		this.fineAmount = fineAmount;
	}
	public String getFineDescription() {
		return fineDescription;
	}
	public void setFineDescription(String fineDescription) {
		this.fineDescription = fineDescription;
	}
	/*
	 * public int getFineInfoId() { return fineInfoId; } public void
	 * setFineInfoId(int fineInfoId) { this.fineInfoId = fineInfoId; } public
	 * UserInfoBean getUserInfo() { return userInfo; } public void
	 * setUserInfo(UserInfoBean userInfo) { this.userInfo = userInfo; }
	 */
	
	
}
