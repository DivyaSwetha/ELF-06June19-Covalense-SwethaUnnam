package com.covalense.lms.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.catalina.startup.HostRuleSet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.covalense.lms.dto.BookInfoBean;
import com.covalense.lms.dto.IssueInfoBean;
import com.covalense.lms.dto.LibraryResponse;
import com.covalense.lms.dto.UserInfoBean;
import com.covalense.lms.repositry.LibraryRepositry;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class UserController {

	@Autowired
	LibraryRepositry repositry;

	@GetMapping(path = "/getUser", produces = MediaType.APPLICATION_JSON_VALUE)
	public LibraryResponse getUser(int userId, HttpServletRequest request) {
		LibraryResponse response = new LibraryResponse();
		if (request.getSession(false) != null) {
			if (repositry.existsById(userId)) {
				UserInfoBean bean = repositry.findById(userId).get();
				response.setStatusCode(201);
				response.setMessage("Successful");
				response.setDescription("User data found successfully");
				response.setBeans(Arrays.asList(bean));
			} else {
				response.setStatusCode(401);
				response.setMessage("Failed!");
				response.setDescription("User data not found!!!");
			}

		} else {
			response.setStatusCode(501);
			response.setMessage("Failed!");
			response.setDescription("Plz Login first");
		}
		return response;
	}

	@PostMapping(path = "/createUser", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public LibraryResponse createUser(@RequestBody UserInfoBean bean, HttpServletRequest request) {

		/* bean = userDetails(bean); */
		LibraryResponse response = new LibraryResponse();
		if (request.getSession(false) != null) {

			if (!repositry.existsById(bean.getUserId())) {
				repositry.save(bean);
				response.setStatusCode(201);

				response.setMessage("Successful");
				response.setDescription("User data added successfully");
			} else {
				response.setStatusCode(401);
				response.setMessage("Failed!");
				response.setDescription("User data is already present!!!");
			}
		} else {
			response.setStatusCode(501);
			response.setMessage("Failed!");
			response.setDescription("please login first");
		}
		return response;

	}

	@DeleteMapping(path = "/deleteUser", produces = MediaType.APPLICATION_JSON_VALUE)
	public LibraryResponse deleteUser(@RequestParam("userId") int userId, HttpServletRequest request) {
		LibraryResponse response = new LibraryResponse();
		if (request.getSession(false) != null) {

			if (repositry.existsById(userId)) {
				repositry.deleteById(userId);
				response.setStatusCode(201);
				response.setMessage("Successful");
				response.setDescription("User data deleted successfully");
			} else {
				response.setStatusCode(401);
				response.setMessage("Failed!");
				response.setDescription("User details not found!!!");
			}
		} else {
			response.setStatusCode(501);
			response.setMessage("Failed!");
			response.setDescription("please login first");
		}
		return response;

	}

	@PatchMapping(path = "/updateUser", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public LibraryResponse updateUser(@RequestBody UserInfoBean bean, HttpServletRequest request) {

		LibraryResponse response = new LibraryResponse();
		if (request.getSession(false) != null) {
			if (repositry.existsById(bean.getUserId())) {
				/*
				 * bean.getUserOtherInfo().setUserOtherId(repositry.findByUserId(bean).
				 * getUserOtherId());
				 */
				/* bean = userDetails(bean); */
				repositry.save(bean);
				response.setStatusCode(201);
				response.setMessage("Successful");
				response.setDescription("User data updated successfully");
			} else {
				response.setStatusCode(401);
				response.setMessage("Failed!");
				response.setDescription("User details not found/updated!!!");
			}
		} else {
			response.setStatusCode(501);
			response.setMessage("Failed!");
			response.setDescription("please login first");
		}
		return response;
	}

	@GetMapping(path = "/getAllUsers", produces = MediaType.APPLICATION_JSON_VALUE)
	public LibraryResponse getAllUsers(HttpServletRequest request) {
		List<UserInfoBean> beans = new ArrayList<UserInfoBean>();
		Iterable<UserInfoBean> itr = repositry.findAll();
		itr.forEach(beans::add);
		LibraryResponse response = new LibraryResponse();
		if (request.getSession(false) != null) {

			if (beans != null) {
				response.setStatusCode(201);
				response.setMessage("Successful");
				response.setDescription("All Employees details found successfully");
				response.setBeans(beans);
			} else {
				response.setStatusCode(401);
				response.setMessage("Failed!");
				response.setDescription("Employees details not found!!!");
			}
		} else {
			response.setStatusCode(501);
			response.setMessage("Failed!");
			response.setDescription("please login first");
		}
		return response;
	}

	/*
	 * private UserInfoBean userDetails(UserInfoBean bean) {
	 * bean.getUserOtherInfo().setUserInfo(bean); for(BookInfoBean
	 * books:bean.getBookInfoBeans()){ UserInfoBean lib=bean.getLibrarianId();
	 * if(lib!=null) { lib = repositry.findById(lib.getUserId()).get();
	 * bean.setLibrarianId(lib); } }
	 * 
	 * for(IssueInfoBean issues:bean.getIssueInfoBeans()) {
	 * issues.getIssuePk().setUserInfo(bean); }
	 * bean.getFineInfo().setUserInfo(bean);
	 * 
	 * return bean; }
	 */
	@PostMapping(path = "/searchUser", produces = MediaType.APPLICATION_JSON_VALUE)
	public LibraryResponse searchUser(@RequestParam("userId") int userId, HttpServletRequest request) {
		LibraryResponse response = new LibraryResponse();
		if (repositry.existsById(userId)) {
			UserInfoBean bean = repositry.findById(userId).get();
			request.getSession(false).setAttribute("user", bean);
			response.setStatusCode(201);
			response.setMessage("Successful");
			response.setDescription("User data found successfully");
			response.setBeans(Arrays.asList(bean));
		} else {
			response.setStatusCode(401);
			response.setMessage("Failed!");
			response.setDescription("User data not found!!!");
		}
		return response;
	}

	@GetMapping(path = "/msg")
	public String getM() {
		return "Hello world";
	}
}
