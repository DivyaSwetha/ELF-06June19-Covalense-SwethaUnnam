package com.covalense.lms.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.covalense.lms.dto.BookInfoBean;
import com.covalense.lms.dto.LibraryResponse;
import com.covalense.lms.repositry.BookRepositry;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class BooksController {
	
	@Autowired
	BookRepositry repositry;

	@GetMapping(path = "/getBook", produces = MediaType.APPLICATION_JSON_VALUE)
	public LibraryResponse getBook(int bookNo,HttpServletRequest request) {
		LibraryResponse response = new LibraryResponse();
		if (request.getSession(false) != null) {
		if (repositry.existsById(bookNo)) {
		 BookInfoBean bean= repositry.findBookId(bookNo);
			response.setStatusCode(201);
			response.setMessage("Successful");
			response.setDescription("Book data found successfully");
			response.setBookBeans(Arrays.asList(bean));
		} else {
			response.setStatusCode(401);
			response.setMessage("Failed!");
			response.setDescription("Book data not found!!!");
		}
		}else {
			response.setStatusCode(501);
			response.setMessage("Failed!");
			response.setDescription("Login first");
		}
		return response;
	}
	
	@PostMapping(path = "/insertBook", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public LibraryResponse inserBook(@RequestBody BookInfoBean bean,HttpServletRequest request) {

       
		LibraryResponse response = new LibraryResponse();
		if (request.getSession(false) != null) {
		if (!repositry.existsById(bean.getBookNo())) {
			/*
			 * repositry.save(bean); response.setStatusCode(201);
			 * 
			 * response.setMessage("Successful");
			 * response.setDescription("Book  added successfully");
			 */
			if(repositry.booksCount(bean.getBookTitle())>=10) {
				response.setStatusCode(401);
				response.setMessage("Failed!");
				response.setDescription("10 copies of this book are already present!!!");
			}else {
				repositry.save(bean);
				response.setStatusCode(201);
				
				response.setMessage("Successful");
				response.setDescription("Book  added successfully");
			}
		} else {
			response.setStatusCode(401);
			response.setMessage("Failed!");
			response.setDescription("Book not added successfully");
			
		}
		}else {
			response.setStatusCode(501);
			response.setMessage("Failed!");
			response.setDescription("Login first");
		}
		return response;

	}
	@DeleteMapping(path = "/deleteBook", produces = MediaType.APPLICATION_JSON_VALUE)
	public LibraryResponse deleteBook(@RequestParam("bookNo")int bookNo,HttpServletRequest request) {
		LibraryResponse response = new LibraryResponse();
		if (request.getSession(false) != null) {
		if (repositry.existsById(bookNo)) {
			repositry.deleteById(bookNo);
			response.setStatusCode(201);
			response.setMessage("Successful");
			response.setDescription("Book  deleted successfully");
		} else {
			response.setStatusCode(401);
			response.setMessage("Failed!");
			response.setDescription("Book details not found!!!");
		}

	}
		else {
			response.setStatusCode(501);
			response.setMessage("Failed!");
			response.setDescription("Login first");
		}

		return response;
	}
	
	@PatchMapping(path = "/updateBook", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public LibraryResponse updateUser(@RequestBody BookInfoBean bean,HttpServletRequest request) {

		LibraryResponse response = new LibraryResponse();
		if (repositry.existsById(bean.getBookNo())) {
			repositry.save(bean);
			response.setStatusCode(201);
			response.setMessage("Successful");
			response.setDescription("Book data updated successfully");
		} else {
			response.setStatusCode(401);
			response.setMessage("Failed!");
			response.setDescription("Book details not found/updated!!!");
		}
		return response;
	}
	
	@GetMapping(path = "/getAllBooks", produces = MediaType.APPLICATION_JSON_VALUE)
	public LibraryResponse getAllUsers(HttpServletRequest request) {
		List<BookInfoBean> beans=new ArrayList<BookInfoBean>();
		Iterable<BookInfoBean> itr = repositry.findAll();

		
		itr.forEach(beans::add);
		
		LibraryResponse response = new LibraryResponse();
		if (!beans.isEmpty()) {
			response.setStatusCode(201);
			response.setMessage("Successful");
			response.setDescription("All Books found successfully");
			response.setBookBeans(beans);
		} else {
			response.setStatusCode(401);
			response.setMessage("Failed!");
			response.setDescription("All Books  not found!!!");
		}
		return response;
	}
	
	@GetMapping(path = "/searchBook", produces = MediaType.APPLICATION_JSON_VALUE)
	public LibraryResponse searchBook(int bookNo,HttpServletRequest request) {
		LibraryResponse response = new LibraryResponse();
		if (request.getSession(false) != null) {
		if (repositry.existsById(bookNo)) {
		 BookInfoBean bean= repositry.findBookId(bookNo);
			response.setStatusCode(201);
			response.setMessage("Successful");
			response.setDescription("Book data found successfully");
			response.setBookBeans(Arrays.asList(bean));
		} else {
			response.setStatusCode(401);
			response.setMessage("Failed!");
			response.setDescription("Book data not found!!!");
		}
		}else {
			response.setStatusCode(501);
			response.setMessage("Failed!");
			response.setDescription("Login first");
		}
		return response;
	}
	
}
