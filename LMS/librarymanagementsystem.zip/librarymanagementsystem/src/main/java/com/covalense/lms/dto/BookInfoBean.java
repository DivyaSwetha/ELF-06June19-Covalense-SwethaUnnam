package com.covalense.lms.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="book_info")
public class BookInfoBean implements Serializable{
	
	@Id
	@Column(name="book_no")
	private int bookNo;
	@Column(name="book_title")
	private String bookTitle;
	@Column(name="author")
	private String author;
	@Column(name="category")
	private String category;
	@Column(name="publisher")
	private String publisher;
	@Column(name="year_of_publication")
	private Date yearOfPublication;
	@Column(name="no_of_copies")
	private int noOfCopies;
	@Column(name="currently_available")
	private int currentlyAvailable;
	
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name="user_book_info",
			   joinColumns= {@JoinColumn(name="book_no")},
			   inverseJoinColumns = {@JoinColumn(name="user_id")})
	private List<UserInfoBean> userInfoBeans;
	
	public int getBookNo() {
		return bookNo;
	}
	public void setBookNo(int bookNo) {
		this.bookNo = bookNo;
	}
	public String getBookTitle() {
		return bookTitle;
	}
	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public Date getYearOfPublication() {
		return yearOfPublication;
	}
	public void setYearOfPublication(Date yearOfPublication) {
		this.yearOfPublication = yearOfPublication;
	}
	public int getNoOfCopies() {
		return noOfCopies;
	}
	public void setNoOfCopies(int noOfCopies) {
		this.noOfCopies = noOfCopies;
	}
	public int getCurrentlyAvailable() {
		return currentlyAvailable;
	}
	public void setCurrentlyAvailable(int currentlyAvailable) {
		this.currentlyAvailable = currentlyAvailable;
	}
	
	
	
	

}
