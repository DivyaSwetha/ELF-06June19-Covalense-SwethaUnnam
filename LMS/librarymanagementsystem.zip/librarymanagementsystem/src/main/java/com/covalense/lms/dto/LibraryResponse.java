package com.covalense.lms.dto;

import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonRootName;
@JsonRootName("library-response")
@Component
public class LibraryResponse {
	private int statusCode;
	private String message;
	private String description;
	private List<UserInfoBean> beans;
	private List<BookInfoBean> bookBeans;
	
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<UserInfoBean> getBeans() {
		return beans;
	}
	public void setBeans(List<UserInfoBean> beans) {
		this.beans = beans;
	}
	public List<BookInfoBean> getBookBeans() {
		return bookBeans;
	}
	public void setBookBeans(List<BookInfoBean> bookBeans) {
		this.bookBeans = bookBeans;
	}
	
	
	
	
}
