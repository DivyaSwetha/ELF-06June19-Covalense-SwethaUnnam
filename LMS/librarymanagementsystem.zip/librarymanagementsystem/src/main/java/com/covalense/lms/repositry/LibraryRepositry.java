package com.covalense.lms.repositry;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.covalense.lms.dto.BookInfoBean;
import com.covalense.lms.dto.UserInfoBean;
import com.covalense.lms.dto.UserOtherInfoBean;

public interface LibraryRepositry extends CrudRepository<UserInfoBean, Integer>{
	/*
	 * @Query("select u from UserOtherInfoBean u where u.userInfo=:userId") public
	 * UserOtherInfoBean findByUserId(@Param("userId") UserInfoBean bean);
	 */
	

}

