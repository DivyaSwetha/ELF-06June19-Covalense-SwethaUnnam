package com.covalense.lms.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;


@SuppressWarnings("serial")
@JsonIdentityInfo(generator=ObjectIdGenerators.PropertyGenerator.class,property="userId")
@JsonRootName(value="user-info")
@Entity
@Table(name="user_info")
public class UserInfoBean implements Serializable {
	/*
	 * @LazyCollection(LazyCollectionOption.FALSE)
	 * 
	 * @OneToOne(cascade=CascadeType.ALL,mappedBy = "userInfo")
	 * 
	 * @JsonProperty(value="other-info") private UserOtherInfoBean userOtherInfo;
	 * 
	 * @JsonProperty(value="book-info")
	 * 
	 * @LazyCollection(LazyCollectionOption.FALSE)
	 * 
	 * @OneToMany(cascade=CascadeType.ALL,mappedBy = "userInfoBeans") private
	 * List<BookInfoBean> bookInfoBeans;
	 * 
	 * @JsonProperty(value="issue-info")
	 * 
	 * @LazyCollection(LazyCollectionOption.FALSE)
	 * 
	 * @OneToMany(cascade=CascadeType.ALL,mappedBy = "issuePk.userInfo") private
	 * List<IssueInfoBean> issueInfoBeans;
	 * 
	 * @LazyCollection(LazyCollectionOption.FALSE)
	 * 
	 * @OneToOne(cascade=CascadeType.ALL,mappedBy = "userInfo")
	 * 
	 * @JsonProperty(value="fine-info") private FineInfoBean fineInfo;
	 */
	@Id
	@Column(name="user_id")
	private int userId;
	@Column(name="user_type")
	private String userType;
	@Column(name="user_name")
	private String userName;
	@Column(name="phone_no")
	private long phoneNo;
	@Column(name="mail_id")
	private String mailId;
	@Column(name="joining_date")
	private Date joiningDate;
	@Column(name="password")
	private String password;
	
	@JsonProperty(value="admin-id")
	@ManyToOne
	@JoinColumn(name="admin_id",referencedColumnName = "user_id")
	private UserInfoBean adminId;
	
	@JsonProperty(value="lib-id")
	@ManyToOne
	@JoinColumn(name="lib_id",referencedColumnName = "user_id")
	private UserInfoBean librarianId;
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public Date getJoiningDate() {
		return joiningDate;
	}
	public void setJoiningDate(Date joiningDate) {
		this.joiningDate = joiningDate;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	/*
	 * public UserOtherInfoBean getUserOtherInfo() { return userOtherInfo; } public
	 * void setUserOtherInfo(UserOtherInfoBean userOtherInfo) { this.userOtherInfo =
	 * userOtherInfo; } public List<BookInfoBean> getBookInfoBeans() { return
	 * bookInfoBeans; } public void setBookInfoBeans(List<BookInfoBean>
	 * bookInfoBeans) { this.bookInfoBeans = bookInfoBeans; } public
	 * List<IssueInfoBean> getIssueInfoBeans() { return issueInfoBeans; } public
	 * void setIssueInfoBeans(List<IssueInfoBean> issueInfoBeans) {
	 * this.issueInfoBeans = issueInfoBeans; }
	 */
	public UserInfoBean getAdminId() {
		return adminId;
	}
	public void setAdminId(UserInfoBean adminId) {
		this.adminId = adminId;
	}
	public UserInfoBean getLibrarianId() {
		return librarianId;
	}
	public void setLibrarianId(UserInfoBean librarianId) {
		this.librarianId = librarianId;
	}
	/*
	 * public FineInfoBean getFineInfo() { return fineInfo; } public void
	 * setFineInfo(FineInfoBean fineInfo) { this.fineInfo = fineInfo; }
	 */
	
	
	
}
