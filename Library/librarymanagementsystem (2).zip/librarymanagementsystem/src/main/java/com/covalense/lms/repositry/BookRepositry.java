package com.covalense.lms.repositry;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.covalense.lms.dto.BookInfoBean;

public interface BookRepositry extends CrudRepository<BookInfoBean, Integer> {
	@Query("select b from BookInfoBean b where b.bookNo=:bookNo")
	public BookInfoBean findBookId(@Param("bookNo") int bookNo);
	
	@Query("select count(b.bookTitle) from BookInfoBean b where b.bookTitle=:bookTitle")
	public int booksCount(@Param("bookTitle") String bookTitle);
}
