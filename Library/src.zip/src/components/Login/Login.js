import React from 'react'
import Axios from 'axios';
import {Link,Router} from 'react-router-dom'
import '../Login/Login.css'

export class Login extends React.Component{
  constructor(props){
    super(props)
        this.state={
            type:'',
            id:'',
            password:'',
        }
        this.postData=this.postData.bind(this);
    }

    postData(event){
        event.preventDefault();
        console.log('post Data',this.state);
        let accountDate=this.state;
        /* Axios.post('http://localhost/emp-springrest/login/authentication',null,
        {params:{type:this.state.type,
                 id:this.state.id,
                 password:this.state.password}})
        .then((response)=>{
             console.log('Response object',response.data);
             if(response.data.statusCode===201){
              sessionStorage.setItem("emp",JSON.stringify(response.data.beans[0]))
        this.props.history.push('/adminhome')
       

             }else{
                 this.props.history.push('/')
             }

      
    }).catch((error)=>{console.log('Error',error);alert('Invalid credentials!!!')}); */
 
      if(this.state.type==="Admin"){
        this.props.history.push('/adminhome')
      }else{
        this.props.history.push('/')
      }
  }


render(){
    return (
            
              <div className="card text-white bg-dark" style={{maxWidth: '30rem',marginTop:'10rem',marginLeft:'35rem'}}>
        <div className="card-header" style={{fontSize:25,marginLeft:'4rem'}}>Library Management System</div>
        <div className="card-body">
         
          <form onSubmit='/adminhome'>
          <div className="form-group">
        <label htmlFor="sel1">Login as:</label>
        <select className="form-control" id="sel1" name="type">
          <option>User</option>
          <option>Librarian</option>
          <option>Admin</option>
        </select>
      </div>
        <div className="form-group">
          <label htmlFor="exampleInputEmail1">Id</label>
          <input type="number" className="form-control" id="exampleInputEmail1" name="id" aria-describedby="emailHelp" placeholder="Enter your library ID" />
        </div>
        <div className="form-group">
          <label htmlFor="exampleInputPassword1">Password</label>
          <input type="password" className="form-control" id="exampleInputPassword1" name="password" placeholder="Password" />
        </div>
       
        <button type="submit" className="btn btn-primary " style={{marginLeft:'10rem'}}>Submit</button>
      </form>
        </div>
      </div>


    );
}



}


export default Login;