import React from 'react'
import '../UserHome/UserHome.css'
import Main from './Userbook';
import $ from 'jquery'

const PRODUCTS = [
    { category: "entertainment", name: "Football" },
    { category: "entertainment", name: "Baseball" },
    { category: "entertainment", name: "Basketball" },
    { category: "fashion", name: "iPod Touch" },
    { category: "design", name: "iPhone 5" },
    { category: "design", name: "Nexus 7" },
    { category: "leisure", name: "Holiday" }
  ];
  
  // get unique category items
  const uniqueItems = (x, i, array) => array.indexOf(x) === i;
  const PRODUCT_CATEGORIES = PRODUCTS.map(prod => prod.category).filter(
    uniqueItems
  );
  
  PRODUCT_CATEGORIES.push("all");
  PRODUCT_CATEGORIES.sort();
export class UserHome extends React.Component{
    componentDidMount() {
       /*  $(document).ready(function(){
        $(".filter-button").click(function(){
        var value = $(this).attr('data-filter');
        if(value == "all")
        {
        //$('.filter').removeClass('hidden');
        $('.filter').show('1000');
        }
        else
        {
        //            $('.filter[filter-item="'+value+'"]').removeClass('hidden');
        //            $(".filter").not('.filter[filter-item="'+value+'"]').addClass('hidden');
        $(".filter").not('.'+value).hide('3000');
        $('.filter').filter('.'+value).show('3000');
        }
      });
        if ($(".filter-button").removeClass("active")) {
        $(this).removeClass("active");
          }
        $(this).addClass("active");
          }
    } */
}

  
    render(){
        return (
                <div>
                      <nav className="navbar navbar-expand-lg bg-dark">
        <a className="navbar-brand" href="#"  style={{color:"whitesmoke"}}>LMS</a>
        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon" />
        </button>
        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav mr-auto">
            <li className="nav-item active">
              <a className="nav-link" href="#"  style={{color:"whitesmoke"}}>Home <span className="sr-only">(current)</span></a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#"  style={{color:"whitesmoke"}}>Logout</a>
            </li>
            {/* <li className="nav-item dropdown">
              <a className="nav-link dropdown-toggle"  style={{color:"whitesmoke"}} href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Users
              </a>
              <div className="dropdown-menu"  style={{color:"whitesmoke"}} aria-labelledby="navbarDropdown">
                <a className="dropdown-item" href="#">Add User</a>
                <a className="dropdown-item" href="#">Delete User</a>
                <a className="dropdown-item" href="#">Edit User</a>
              </div>
            </li> */}
            <li className="nav-item">
              <a className="nav-link" href="#"  style={{color:"whitesmoke"}}>MyBooks</a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#"  style={{color:"whitesmoke"}}>Edit Details</a>
            </li>
          </ul>
          <form className="form-inline my-2 my-lg-0">
            <input className="form-control mr-sm-2" type="search" placeholder="Search by Book-no,Author,Title" aria-label="Search" style={{width:"50rem"}} />
            <button className="btn btn-success my-2 my-sm-0" type="submit">Search</button>
          </form>
        </div>
      </nav>
      
      {/* <Main products={PRODUCTS} productCategories={PRODUCT_CATEGORIES} /> */}
      <div className="container">
        <div className="row">
          <div className="gallery col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <h1 className="gallery-title" style={{marginTop:'2rem',color:'whitesmoke'}}>List Of Books</h1>
          </div>
          <div align="center">
            <button className="btn btn-default filter-button" data-filter="all" style={{color:'whitesmoke'}}>All</button>
            <button className="btn btn-default filter-button" data-filter="hdpe" style={{color:'whitesmoke'}}>Entertainment</button>
            <button className="btn btn-default filter-button" data-filter="sprinkle" style={{color:'whitesmoke'}}>Communication</button>
            <button className="btn btn-default filter-button" data-filter="spray" style={{color:'whitesmoke'}}>Technical</button>
            <button className="btn btn-default filter-button" data-filter="irrigation" style={{color:'whitesmoke'}}>Horror</button>
          </div>
          <br />
          <div className="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter hdpe">
            <img src="https://www.oreilly.com/library/view/the-high-roller/9781259862960/images/Cover.jpg" className="img-responsive" style={{width:'20rem',height:'20rem'}} /><br/>
            <a href="" style={{marginLeft:'5rem',color:'whitesmoke'}}><b>The High Roller</b></a>
          </div>
          <div className="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter sprinkle">
            <img src="https://timedotcom.files.wordpress.com/2019/05/best-fiction-of-the-year-so-far-2019-005.jpg?quality=85" className="img-responsive" style={{width:'20rem',height:'20rem'}} />
            <a href="" style={{marginLeft:'5rem',color:'whitesmoke'}}><b>Miracle Creek</b></a>
          </div>
          <div className="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter hdpe">
            <img src="https://cdn.shopify.com/s/files/1/2162/5801/products/9953331979_F_800x.jpg?v=1518542165" className="img-responsive" style={{width:'20rem',height:'20rem'}}/>
            <a href="" style={{marginLeft:'5rem',color:'whitesmoke'}}><b>Scientific dictionary</b></a>
          </div>
          <div className="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter irrigation">
            <img src="https://www.oreilly.com/library/view/the-javascript-programming/9780763766580/images/cover.jpg" className="img-responsive" style={{width:'20rem',height:'20rem'}}/>
            <a href="" style={{marginLeft:'5rem',color:'whitesmoke'}}><b>Java Script</b></a>
          </div>
          <div className="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter spray">
            <img src="https://www.oreilly.com/library/view/the-high-roller/9781259862960/images/Cover.jpg" className="img-responsive" style={{width:'20rem',height:'20rem'}}/>
            <a href="" style={{marginLeft:'5rem',color:'whitesmoke'}}><b>Harry Potter</b></a>
          </div>
          <div className="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter irrigation">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRt839Uw41RWptmP9m22a8njHNB7bDNK1gGXL_qvH17jKzhsSUdKg" className="img-responsive" style={{width:'20rem',height:'20rem'}}/>
            <a href="" style={{marginLeft:'5rem',color:'whitesmoke'}}><b>The plague stones</b></a>
          </div>
          <div className="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter hdpe">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ4DboqyyqVptlxXZqWQ136oMyn3Ps2HnF9-l__OWZ4871CTfZH" className="img-responsive" style={{width:'20rem',height:'20rem'}}/>
            <a href="" style={{marginLeft:'5rem',color:'whitesmoke'}}><b>Ruskin Bonds</b></a>
          </div>
          <div className="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter spray">
            <img src="https://www.oreilly.com/library/view/the-high-roller/9781259862960/images/Cover.jpg" className="img-responsive" style={{width:'20rem',height:'20rem'}} />
            <a href="" style={{marginLeft:'5rem',color:'whitesmoke'}}><b>Music</b></a>
          </div>
          <div className="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter sprinkle">
            <img src="https://www.oreilly.com/library/view/the-high-roller/9781259862960/images/Cover.jpg" className="img-responsive" style={{width:'20rem',height:'20rem'}}/>
            <a href="" style={{marginLeft:'5rem',color:'whitesmoke'}}><b>Wings of Fire</b></a>
          </div>
        </div>
      </div>
                </div>
        );
       
    }
    
}

export default UserHome;