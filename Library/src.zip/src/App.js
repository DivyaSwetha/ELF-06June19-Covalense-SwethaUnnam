import React from 'react';
import './App.css';
/* import Login from './components/Login/Login';
import AdminHome from './components/AdminHomePage/Homepage';
import User from './components/User/user';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom' */
import Login from './components/Login/Login'
import UserHome from './components/UserHome/UserHome';
import AdminHome from './components/AdminHomePage/Homepage';
import User from './components/User/user';
import BookAdd from './components/Book/BookAdd';
function App() {
  return (
  
<BookAdd/>  
  );
}

export default App;
 /* 
      <Router>
    <Route  exact path='/' component={Login}></Route>
    <Route path='/adminhome' component={AdminHome} ></Route>
    <Route  path='/adduser' component={User}></Route> */
  {/*   <Route path='/viewaccounts' component={ViewAccounts}></Route> */}
  /*    </Router> */
