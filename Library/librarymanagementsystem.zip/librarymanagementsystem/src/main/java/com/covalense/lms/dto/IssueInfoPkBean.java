package com.covalense.lms.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;
@Embeddable
public class IssueInfoPkBean implements Serializable{

	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="user_id")
	private UserInfoBean userInfo;
	@Column(name="book_no")
	private int bookNo;
}
