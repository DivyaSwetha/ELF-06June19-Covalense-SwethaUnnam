package com.covalense.lms.controller;

import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.covalense.lms.dto.LibraryResponse;
import com.covalense.lms.dto.UserInfoBean;
import com.covalense.lms.repositry.LibraryRepositry;

@EntityScan("com.covalense.lms")
@RestController
@RequestMapping("/lib")
public class LoginController {
	@Autowired
	LibraryRepositry repositry;

	@PostMapping(value = "/authentication", produces = MediaType.APPLICATION_JSON_VALUE)
	public LibraryResponse login(String userType,Integer userId,String password, HttpServletRequest request) {
		//EmployeeInfoBean bean=repositry.findEmpById(id);
		UserInfoBean bean=repositry.findById(userId).get();
		
		LibraryResponse response = new LibraryResponse();
		if (bean!=null&& bean.getPassword().equals(password)&&bean.getUserType().equalsIgnoreCase(userType)) {
			response.setStatusCode(201);
			response.setMessage("Successfull");
			response.setDescription("login successfull");
			response.setBeans(Arrays.asList(bean));
			request.getSession().setAttribute("bean", bean);
		} else {
			response.setStatusCode(401);
			response.setMessage("Failed!");
			response.setDescription("invalid credentials!!! login failed");
		}
		return response;
	}

	@GetMapping(value = "/logout", produces = MediaType.APPLICATION_JSON_VALUE)
	public LibraryResponse logout(HttpSession session) {
		session.invalidate();
		LibraryResponse response = new LibraryResponse();
		response.setStatusCode(201);
		response.setMessage("Successfull");
		response.setDescription("logged out successfully");
		return response;
	}

	@GetMapping(value = "/readCookie", produces = MediaType.APPLICATION_JSON_VALUE)
	public LibraryResponse readCookie(@CookieValue(name = "JSESSIONID") String sessionId) {
		LibraryResponse response = new LibraryResponse();
		response.setStatusCode(201);
		response.setMessage("Successfull");
		response.setDescription("JSESSIONID" + sessionId);
		return response;

	}
}
