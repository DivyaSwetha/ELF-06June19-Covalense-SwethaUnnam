package com.covalense.lms.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="user_other")
public class UserOtherInfoBean implements Serializable {
	@JsonIgnore
	@Id
	@GeneratedValue
	@Column(name="user_other_id")
	private int UserOtherId;
	
	@JsonIgnore
	@OneToOne
	@JoinColumn(name="user_id",referencedColumnName = "user_id", unique = true, nullable=false)
	private UserInfoBean userInfo;
	
	@Column(name="address")
	private String address;
	@Column(name="alt_phone")
	private long alternativePh;
	@Column(name="dob")
	private Date dob;
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long getAlternativePh() {
		return alternativePh;
	}
	public void setAlternativePh(long alternativePh) {
		this.alternativePh = alternativePh;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public int getUserOtherId() {
		return UserOtherId;
	}
	public void setUserOtherId(int userOtherId) {
		UserOtherId = userOtherId;
	}
	public UserInfoBean getUserInfo() {
		return userInfo;
	}
	public void setUserInfo(UserInfoBean userInfo) {
		this.userInfo = userInfo;
	}
	
	
	
	
}
