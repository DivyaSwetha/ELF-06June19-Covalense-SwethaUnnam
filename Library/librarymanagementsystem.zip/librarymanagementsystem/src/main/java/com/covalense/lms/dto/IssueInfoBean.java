package com.covalense.lms.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@SuppressWarnings("serial")
@Entity
@Table(name="issue_info")
public class IssueInfoBean implements Serializable{
	@EmbeddedId
	private IssueInfoPkBean issuePk;
	@Column(name="issued_by")
	private String issuedBy;
	@Column(name="issued_on")
	private Date issuedOn;
	@Column(name="closed_on")
	private Date closedOn;
	public String getIssuedBy() {
		return issuedBy;
	}
	public void setIssuedBy(String issuedBy) {
		this.issuedBy = issuedBy;
	}
	public Date getIssuedOn() {
		return issuedOn;
	}
	public void setIssuedOn(Date issuedOn) {
		this.issuedOn = issuedOn;
	}
	public Date getClosedOn() {
		return closedOn;
	}
	public void setClosedOn(Date closedOn) {
		this.closedOn = closedOn;
	}
	public IssueInfoPkBean getIssuePk() {
		return issuePk;
	}
	public void setIssuePk(IssueInfoPkBean issuePk) {
		this.issuePk = issuePk;
	}

	
	
}
