package com.covalense.lms.repositry;

import org.springframework.data.repository.CrudRepository;

import com.covalense.lms.dto.UserInfoBean;

public interface LibraryRepositry extends CrudRepository<UserInfoBean, Integer>{

}
