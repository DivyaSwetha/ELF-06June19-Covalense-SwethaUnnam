package com.covalense.lms.controller;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.covalense.lms.dto.LibraryResponse;
import com.covalense.lms.dto.UserInfoBean;
import com.covalense.lms.repositry.LibraryRepositry;


@RestController
public class LibraryController {

	@Autowired
	LibraryRepositry repositry;
	
	@GetMapping(path = "/getUser", produces = MediaType.APPLICATION_JSON_VALUE)
	public LibraryResponse getEmployee(int userId) {
		LibraryResponse response = new LibraryResponse();
		if (repositry.existsById(userId)) {
			UserInfoBean bean = repositry.findById(userId).get();
			response.setStatusCode(201);
			response.setMessage("Successful");
			response.setDescription("User data found successfully");
			response.setBeans(Arrays.asList(bean));
		} else {
			response.setStatusCode(401);
			response.setMessage("Failed!");
			response.setDescription("User data not found!!!");
		}
		return response;
	}
	
	@GetMapping(path="/msg")
	public String getM() {
		return "Hello world";
	}
}
